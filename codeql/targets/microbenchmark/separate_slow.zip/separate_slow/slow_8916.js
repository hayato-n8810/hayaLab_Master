for (VAR_4 = 0; VAR_4 < VAR_3; ++VAR_4) {
  VAR_7 = VAR_7.concat(" ");
  VAR_7 = VAR_7.concat(VAR_1[VAR_4 & 3]);
  VAR_7 = VAR_7.concat(VAR_2++);
}
VAR_6 = VAR_5.test(VAR_7);