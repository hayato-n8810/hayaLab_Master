for (let [VAR_4, VAR_5] of Object.entries(VAR_1)) {
  VAR_2 += VAR_4;
  VAR_3 += VAR_5;
}