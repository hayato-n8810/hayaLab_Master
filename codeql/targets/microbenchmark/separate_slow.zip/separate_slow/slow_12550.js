function FUNCTION_1(VAR_1) {
  return ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][VAR_1 - 1];
}
var VAR_2 = 100;
do {
  FUNCTION_1(12);
} while (VAR_2--);