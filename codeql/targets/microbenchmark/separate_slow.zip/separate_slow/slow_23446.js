var VAR_3 = 0;
var VAR_4;
for (VAR_3; VAR_3 < VAR_1.length; VAR_3++) {
  VAR_4 = VAR_1[VAR_3];
}