for (VAR_5 = 0, VAR_8 = 64; VAR_5 < VAR_8; VAR_5++) {
  VAR_4.push(VAR_2[VAR_5].charCodeAt(0));
}