const VAR_4 = VAR_1.reduce((VAR_5, VAR_6) => Object.assign(VAR_5, {
  [VAR_6.KEY_1]: VAR_6
}), {});