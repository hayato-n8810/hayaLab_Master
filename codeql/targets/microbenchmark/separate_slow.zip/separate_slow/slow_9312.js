var VAR_1 = new Array(8);
for (var VAR_2 = 0; VAR_2 < 8;) {
  VAR_1[VAR_2++] = "Julio Test";
}
var VAR_3 = String.prototype.concat.apply(VAR_1);