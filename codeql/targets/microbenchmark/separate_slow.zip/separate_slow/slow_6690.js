var VAR_1 = 10000;
while (VAR_1--) {
  1 == 1;
}