var VAR_3 = new Set([VAR_2]);
var VAR_4 = [];
for (var VAR_5 = 0; VAR_5 < 1000; VAR_5++) {
  VAR_4.push(VAR_5 * 2);
}
var VAR_6 = [];
for (var VAR_7 = 0; VAR_5 < VAR_4.length; VAR_5++) {
  if (VAR_3.has(VAR_4[VAR_5])) {
    VAR_6.push(VAR_4[VAR_5]);
  }
}