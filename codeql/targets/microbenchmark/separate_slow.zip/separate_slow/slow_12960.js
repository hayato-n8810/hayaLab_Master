var VAR_1 = {
  KEY_1: 0
};
for (var VAR_2 = 0; VAR_2 < 10; VAR_2++) VAR_1.KEY_1++;