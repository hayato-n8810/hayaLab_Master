for (var VAR_6 = 0, VAR_7 = VAR_1.length; VAR_6 < VAR_7; VAR_6++) {
  if (VAR_1[VAR_6].match(VAR_3)) {
    break;
  }
}