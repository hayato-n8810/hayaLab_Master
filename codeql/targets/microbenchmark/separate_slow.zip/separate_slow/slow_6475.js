var FUNCTION_1 = function () {
  return arguments[0] * arguments[1] * arguments[2] * arguments[3];
};
for (var VAR_1 = 0; VAR_1 < 1000; VAR_1++) {
  FUNCTION_1.apply(this, [2, 3, 4, 5]);
}