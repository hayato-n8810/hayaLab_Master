var VAR_1 = "0123456789ABCDEF".split("");
var VAR_2 = "#";
for (var VAR_3 = 0; VAR_3 < 6; VAR_3++) {
  VAR_2 += VAR_1[Math.floor(Math.random() * 16)];
}