String.prototype.FUNCTION_1 = function (VAR_2) {
  if (VAR_2 === "") return true;
  if (!VAR_2) return false;
  var VAR_3 = this;
  if (VAR_2.length > VAR_3.length) {
    return false;
  }
  for (var VAR_4 = 0; VAR_4 < VAR_2.length; VAR_4++) {
    if (VAR_3.charAt(VAR_4) !== VAR_2.charAt(VAR_4)) {
      return false;
    }
  }
  return true;
};
VAR_1.FUNCTION_1("moj nowy");