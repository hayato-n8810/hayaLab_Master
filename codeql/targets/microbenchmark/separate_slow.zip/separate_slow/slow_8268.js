function FUNCTION_1(VAR_1, VAR_2) {
  var VAR_3 = new RegExp("(-?[0-9]+)([0-9]{3})"),
    VAR_4 = VAR_1 + "";
  if (VAR_2 === undefined) {
    VAR_2 = ",";
  }
  while (VAR_3.test(VAR_4)) {
    VAR_4 = VAR_4.replace(VAR_3, "$1" + VAR_2 + "$2");
  }
  return VAR_4;
}
FUNCTION_1(1000357);