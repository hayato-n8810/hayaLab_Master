for (var VAR_7 = 0; VAR_5 < 1000; VAR_5++) {
  if (VAR_3[VAR_5].constructor.name === VAR_4[VAR_5].constructor.name) VAR_6++;
}