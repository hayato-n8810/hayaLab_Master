while (VAR_3[0].KEY_1 < 5) VAR_3.shift();
if (VAR_3.length !== 500) throw new Error();