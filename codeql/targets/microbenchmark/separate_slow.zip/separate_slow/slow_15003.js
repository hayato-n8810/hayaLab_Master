(function (VAR_1) {
  var VAR_2 = [];
  next: for (var VAR_3 = 0; VAR_3 < VAR_1.length; VAR_3++) {
    var VAR_4 = VAR_1[VAR_3];
    for (var VAR_5 = 0; VAR_5 < VAR_2.length; VAR_5++) {
      if (VAR_2[VAR_5] == VAR_4) continue next;
    }
    VAR_2.push(VAR_4);
  }
  return VAR_2;
})([1, 2, 6, 1, 2, 5, 4, 3, 1, 2, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]);