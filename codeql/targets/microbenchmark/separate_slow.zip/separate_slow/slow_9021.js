var VAR_1 = new function (VAR_2) {
  var VAR_3 = 0;
  for (var VAR_4 = 0; VAR_4 < VAR_2; VAR_4++) {
    VAR_3++;
  }
}(1000);