var VAR_3 = [];
var VAR_4 = VAR_1.VAR_4;
for (var VAR_5 = 0; VAR_5 < VAR_4; VAR_5++) {
  if (VAR_1[VAR_5] !== VAR_2) {
    VAR_3.push(VAR_1[VAR_5]);
  }
}