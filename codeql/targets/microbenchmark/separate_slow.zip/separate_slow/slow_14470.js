var VAR_2 = "";
var VAR_3 = VAR_1.length;
while (VAR_3--) {
  VAR_2 += VAR_1.charAt(VAR_3);
}