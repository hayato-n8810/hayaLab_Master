var VAR_7 = VAR_3.slice();
while (VAR_7.length > 0) {
  VAR_7.pop();
}