while (VAR_4 = VAR_5.shift()) {
  FUNCTION_1(VAR_4);
}