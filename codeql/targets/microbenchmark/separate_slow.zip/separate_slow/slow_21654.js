var VAR_1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
var VAR_2 = {
  KEY_1: VAR_1
};
for (var VAR_3 = 0; VAR_3 < VAR_2.KEY_1.length; VAR_3++) {}