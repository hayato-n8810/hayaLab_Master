function FUNCTION_1(VAR_1) {
  var VAR_2 = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  return VAR_2[VAR_1 - 1];
}
var VAR_3 = 100;
do {
  FUNCTION_1(12);
} while (VAR_3--);