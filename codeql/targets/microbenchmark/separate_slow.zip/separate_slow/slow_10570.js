const FUNCTION_1 = (VAR_1, VAR_2, VAR_3 = []) => VAR_1.length <= VAR_2 ? [...VAR_3, VAR_1] : FUNCTION_1(VAR_1.slice(VAR_2), VAR_2, [...VAR_3, VAR_1.slice(0, VAR_2)]);
FUNCTION_1([1, 2, 3, 4], 2);
FUNCTION_1([1, 2, 3, 4, 5], 2);
FUNCTION_1([1, 2, 3, 4, 5, 6, 7, 8], 3);
FUNCTION_1([1, 2, 3, 4, 5], 4);
FUNCTION_1([1, 2, 3, 4, 5], 10);