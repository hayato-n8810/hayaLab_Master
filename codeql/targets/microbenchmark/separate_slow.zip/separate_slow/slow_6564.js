function FUNCTION_1(VAR_4) {
  var VAR_5 = "",
    VAR_6 = 1;
  while ((VAR_6 = VAR_6 * 2) <= VAR_4) {}
  VAR_6 /= 2;
  while (VAR_6 >= 1) {
    if (VAR_4 >= VAR_6) {
      VAR_5 += "1";
      VAR_4 -= VAR_6;
    } else {
      VAR_5 += "0";
    }
    VAR_6 /= 2;
  }
  return VAR_5;
}
FUNCTION_1(VAR_1);
FUNCTION_1(VAR_2);
FUNCTION_1(VAR_3);