var VAR_1 = "variableValue",
  VAR_2,
  VAR_3 = 1,
  VAR_4 = 2,
  VAR_5 = 1,
  VAR_6 = 2,
  VAR_7 = 3,
  VAR_8 = true,
  VAR_9 = 2;
function FUNCTION_1() {}
function FUNCTION_2() {}
function FUNCTION_3() {}
var VAR_10 = {
  "Document language": "HTML5",
  "Styling language": "CSS3",
  "Javascript library": "jQuery",
  KEY_1: "Usability and accessibility"
};