while (--VAR_1 + 1 > 0) {
  VAR_2 = VAR_4;
  while (--VAR_2 + 1 > 0) {
    VAR_3 = VAR_4;
    while (--VAR_3 + 1 > 0) {
      VAR_3;
    }
  }
}