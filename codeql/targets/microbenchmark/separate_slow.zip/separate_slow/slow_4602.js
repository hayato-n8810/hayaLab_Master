var VAR_2 = [];
VAR_1.replace(/.{1,3}/g, function (VAR_3) {
  VAR_2.push(VAR_3);
});