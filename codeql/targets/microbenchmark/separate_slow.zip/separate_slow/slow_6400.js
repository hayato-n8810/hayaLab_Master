(function (VAR_1) {
  var VAR_2 = 0;
  while (!(Math.pow(2, VAR_2 - 1) <= VAR_1 && VAR_1 <= Math.pow(2, VAR_2) - 1)) VAR_2++;
  return VAR_2;
})(2014);