for (var VAR_2 = 0; VAR_2 < 1000; VAR_2++) {
  new Set(VAR_1).has("2Cabbage");
}