FUNCTION_1(VAR_4, 100);
while (VAR_4.length > 0) VAR_4.pop();