var VAR_1 = "    sDAFSdasf afsd fads        sDAFSdasf afsd fads        ";
VAR_1 = VAR_1.replace(/^\s+/, "");
for (var VAR_2 = VAR_1.length - 1; VAR_2 >= 0; VAR_2--) {
  if (/\S/.test(VAR_1.charAt(VAR_2))) {
    VAR_1 = VAR_1.substring(0, VAR_2 + 1);
    break;
  }
}