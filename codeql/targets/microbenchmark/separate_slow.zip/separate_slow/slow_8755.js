var VAR_2 = "<ul>";
for (var VAR_3 = 0; VAR_3 < VAR_1.length; VAR_3++) {
  VAR_2 += "<li>" + VAR_1[VAR_3] + "</li>";
}
VAR_2 += "</ul>";