var VAR_7;
for (VAR_7 = 0; VAR_7 < VAR_4.length; VAR_7++) {
  if (!(VAR_4[VAR_7].KEY_1 in VAR_5)) {
    VAR_5[VAR_4[VAR_7].KEY_1] = true;
    VAR_6.push(VAR_4[VAR_7]);
  }
}