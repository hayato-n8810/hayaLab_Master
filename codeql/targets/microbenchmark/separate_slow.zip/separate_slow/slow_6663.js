var VAR_1 = 25,
  VAR_2 = 25;
for (var VAR_3 = 0; VAR_3 < 400; VAR_3++) {
  VAR_1 *= VAR_2;
}