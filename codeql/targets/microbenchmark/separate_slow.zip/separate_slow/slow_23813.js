if (VAR_2 instanceof Array) {
  for (VAR_1 = 0; VAR_1 < VAR_2.length; VAR_1++) {
    FUNCTION_1(VAR_2[VAR_1]);
  }
} else {
  FUNCTION_1(VAR_2);
}