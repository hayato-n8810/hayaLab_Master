var VAR_1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
  VAR_2 = 0,
  VAR_3;
for (; VAR_2 < VAR_1.length; VAR_2++) {
  VAR_3 = VAR_1[VAR_2];
}