for (const VAR_5 of VAR_1) {
  FUNCTION_1(VAR_5);
}