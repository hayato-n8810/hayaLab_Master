var VAR_3 = true;
for (var VAR_4 = 0; VAR_4 < 300000; ++VAR_4) {
  VAR_3 = !VAR_3;
  var VAR_5;
  if (VAR_3) {
    VAR_5 = VAR_1[50];
  } else {
    VAR_5 = VAR_1[0];
  }
}