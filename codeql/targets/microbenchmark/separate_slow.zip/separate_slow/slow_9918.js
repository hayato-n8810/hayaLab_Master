VAR_7 = Array(VAR_5.KEY_1);
for (var VAR_8 = 0; VAR_6 < VAR_5.KEY_1; VAR_6++) {
  VAR_7.push(VAR_1.KEY_2(VAR_5[VAR_6]));
}