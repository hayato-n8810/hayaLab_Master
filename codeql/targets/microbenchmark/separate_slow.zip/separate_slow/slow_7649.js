var VAR_1 = [1, 2, 1, 1, 2, 1, 1, 1, 2, 2];
var VAR_2 = [1, 1, 2, 2];
function FUNCTION_1(VAR_3, VAR_4) {
  var VAR_5 = 1;
  var VAR_6 = 0;
  var VAR_7 = "_";
  var VAR_8 = VAR_4.join(VAR_7);
  for (VAR_5 = 1; VAR_5 <= VAR_2.length; VAR_5++) {
    var VAR_9 = VAR_3.slice(0, VAR_5);
    var VAR_10 = VAR_9.join(VAR_7);
    if (VAR_8.indexOf(VAR_10) >= 0) {
      VAR_6 = VAR_9.length;
    } else {
      break;
    }
  }
  return VAR_6;
}
FUNCTION_1(VAR_2, VAR_1);