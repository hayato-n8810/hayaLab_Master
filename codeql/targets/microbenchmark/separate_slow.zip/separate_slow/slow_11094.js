var VAR_1 = {
  KEY_1: 1,
  KEY_2: 2,
  KEY_3: 3
};
var VAR_2 = {};
Object.defineProperties(VAR_2, {
  KEY_4: {
    KEY_5: true,
    KEY_6: true,
    KEY_7: 1
  }
});
function FUNCTION_1(VAR_3) {
  return !Object.keys(VAR_3).length;
}
function FUNCTION_2(VAR_4) {
  for (var VAR_5 in VAR_4) {
    return false;
  }
  return true;
}
function FUNCTION_3(VAR_6) {
  return !Object.getOwnPropertyNames(VAR_6).length;
}
FUNCTION_3(VAR_2);