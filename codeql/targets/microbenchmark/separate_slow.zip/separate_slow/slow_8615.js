var VAR_1 = [];
for (var VAR_2 = 0; VAR_2 < 10; VAR_2++) {
  VAR_1.push("iteration: " + VAR_2);
}
VAR_1.join(" ");