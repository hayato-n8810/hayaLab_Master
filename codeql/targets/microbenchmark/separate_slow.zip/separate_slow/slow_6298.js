var FUNCTION_1 = function (VAR_1) {
  return VAR_1 < 2 ? VAR_1 : FUNCTION_1(VAR_1 - 1) + FUNCTION_1(VAR_1 - 2);
};
for (var VAR_2 = 0; VAR_2 <= 10; VAR_2++) {
  FUNCTION_1(VAR_2);
}