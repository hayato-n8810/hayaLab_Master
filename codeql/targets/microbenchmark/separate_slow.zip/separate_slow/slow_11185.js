while (VAR_2-- > 0) {
  VAR_1 = VAR_2 / 10;
  VAR_1 + 0.5 + (VAR_1 - 0.5 >> 63) | 0;
}