function FUNCTION_1(VAR_3) {
  return (parseInt(VAR_3) === VAR_3 || parseFloat(VAR_3) === VAR_3) && isFinite(VAR_3);
}
function FUNCTION_2(VAR_4) {
  return !isNaN(VAR_4) && isFinite(VAR_4) && VAR_2.call(VAR_4) == "[object Number]";
}
for (var VAR_5 = 0; VAR_5 < VAR_1.length; VAR_5++) {
  FUNCTION_1(VAR_1[VAR_5]);
}