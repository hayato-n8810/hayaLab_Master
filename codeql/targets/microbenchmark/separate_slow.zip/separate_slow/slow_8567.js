var VAR_1 = Math.log(10);
function FUNCTION_1(VAR_2) {
  VAR_2 = Math.abs(VAR_2);
  while (VAR_2 % 1 != 0) VAR_2 *= 10;
  while (VAR_2 != 0 && VAR_2 % 10 == 0) VAR_2 /= 10;
  return Math.floor(Math.log(VAR_2) / VAR_1) + 1;
}
function FUNCTION_2(VAR_3) {
  return VAR_3.toExponential().replace(/^([0-9]+)\.?([0-9]+)?e[\+\-0-9]*$/g, "$1$2").length;
}
FUNCTION_1(2.34);
FUNCTION_1(0.0034);
FUNCTION_1(120500);