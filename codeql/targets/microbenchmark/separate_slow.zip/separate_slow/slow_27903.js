var VAR_2 = VAR_1.VAR_2;
while (VAR_2--) {
  if (VAR_1[VAR_2].KEY_1 === 2) {
    break;
  }
}