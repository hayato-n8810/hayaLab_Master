for (var VAR_4 in VAR_3) {
  if (VAR_4.toLowerCase(VAR_4) === "content-type") delete VAR_3[VAR_4];
}