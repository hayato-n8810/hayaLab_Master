function FUNCTION_1(VAR_1, VAR_2) {
  var VAR_3 = [];
  VAR_2 = VAR_2 || VAR_1.VAR_2;
  for (var VAR_4 = 0; VAR_4 < VAR_1.VAR_2 && VAR_4 < VAR_2; VAR_4++) {
    VAR_3.push(VAR_1[VAR_4]);
  }
  return VAR_3;
}
function FUNCTION_2() {
  return FUNCTION_1(arguments);
}
FUNCTION_2(1, 2, 3, 4, 5, 6);