function FUNCTION_1(VAR_1, VAR_2) {
  var VAR_3 = VAR_2.VAR_3;
  for (var VAR_4 = 0; VAR_4 < VAR_3; VAR_4++) {
    if (VAR_1[VAR_4] !== VAR_2[VAR_4]) {
      return false;
    }
  }
  return true;
}
var VAR_5 = new RegExp("^M", "i");
var VAR_6 = new RegExp("^MynamD", "i");
FUNCTION_1("myname", "m");
FUNCTION_1("myname", "mynamd");