(function (VAR_1) {
  return VAR_1.reduce(function (VAR_2, VAR_3) {
    for (var VAR_4 = 0; VAR_4 < VAR_2.length; VAR_4++) {
      if (VAR_2[VAR_4] == VAR_3) return VAR_2;
    }
    VAR_2.push(VAR_3);
    return VAR_2;
  }, []);
})([1, 2, 6, 1, 2, 5, 4, 3, 1, 2, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]);