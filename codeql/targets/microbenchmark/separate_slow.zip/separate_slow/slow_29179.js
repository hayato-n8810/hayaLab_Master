for (var VAR_7 = 0, VAR_8 = VAR_2.length; VAR_4 < VAR_8; ++VAR_4) {
  VAR_2.shift();
}