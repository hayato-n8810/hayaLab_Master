(function x(VAR_2) {
  var VAR_3 = [[], [], [], []];
  VAR_2.split("").forEach(function (VAR_4, VAR_5) {
    VAR_3[~~(VAR_5 / 4)].push(VAR_4);
  });
  return VAR_3;
})(VAR_1);