var FUNCTION_2 = function () {
  return VAR_2;
};
for (var VAR_4 = 0; VAR_4 < 10; VAR_4 += 1) {
  VAR_3.push(FUNCTION_2());
}