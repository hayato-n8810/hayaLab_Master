function FUNCTION_1(VAR_1, VAR_2) {
  var VAR_3 = 0,
    VAR_4 = (VAR_1 || []).length,
    VAR_5 = [];
  if (!VAR_2) {
    return null;
  }
  for (; VAR_3 < VAR_4; VAR_3++) {
    if (VAR_2(VAR_1[VAR_3])) {
      VAR_5.push(VAR_1[VAR_3]);
    }
  }
  return VAR_5.length > 0 ? VAR_5 : null;
}
var VAR_6 = [1, 2, 3, 4, 5, 6, 7, 8];
var VAR_7 = FUNCTION_1(VAR_6, function (VAR_8) {
  VAR_8 % 2 == 0;
});