function FUNCTION_2(VAR_5) {
  var VAR_6;
  do {
    VAR_6 = FUNCTION_1(VAR_5);
  } while (VAR_6.indexOf("+") >= 0 || VAR_6.indexOf("/") >= 0);
  return VAR_6;
}
FUNCTION_2(32);