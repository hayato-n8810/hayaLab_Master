for (var VAR_4 = 0; VAR_4 < 1000; VAR_4++) {
  VAR_2["p" + VAR_4] = null;
}