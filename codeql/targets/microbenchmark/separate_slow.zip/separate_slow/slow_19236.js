var VAR_3 = 40;
var VAR_4 = 10;
var VAR_5 = 20;
var VAR_6 = 0;
var VAR_7 = VAR_4 - 1;
var VAR_8 = VAR_2 - 1;
if (VAR_3 < VAR_4) {
  for (var VAR_9 = VAR_3; VAR_9 < VAR_4; VAR_9++) {
    VAR_6++;
  }
} else {
  for (var VAR_10 = VAR_3; VAR_9 < VAR_2; VAR_9++) {
    VAR_6++;
  }
  for (var VAR_11 = 0; VAR_9 < VAR_4; VAR_9++) {
    VAR_6++;
  }
}