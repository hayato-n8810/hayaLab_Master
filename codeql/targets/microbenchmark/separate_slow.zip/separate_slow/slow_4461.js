for (var VAR_5 = 0, VAR_6 = VAR_1.length, VAR_7, VAR_8; VAR_3 < VAR_6; ++VAR_3) {
  VAR_7 = VAR_1[VAR_3].toFixed().substr(-1);
  VAR_8 = VAR_7 === "0" || VAR_7 === "2" || VAR_7 === "4" || VAR_7 === "6" || VAR_7 === "8";
}