String.prototype.FUNCTION_1 = function (VAR_1) {
  if ((VAR_1 |= 0) <= 0) throw new RangeError();
  var VAR_2 = [];
  while (VAR_1--) VAR_2.push(this);
  return VAR_2.join("");
};
"foo".FUNCTION_1(1000000);