function FUNCTION_1(VAR_2, VAR_3, VAR_4, VAR_5, VAR_6) {
  for (VAR_3 = VAR_3.split ? VAR_3.split(".") : VAR_3, VAR_5 = 0; VAR_5 < VAR_3.length; VAR_5++) VAR_2 = VAR_2 ? VAR_2[VAR_3[VAR_5]] : VAR_6;
  return VAR_2 === VAR_6 ? VAR_4 : VAR_2;
}
FUNCTION_1(VAR_1, ["bar", "baz", "qux"]);