var VAR_1 = {
  KEY_1: 0,
  KEY_2: 0,
  KEY_3: 0,
  KEY_4: 0,
  KEY_5: 0
};
var VAR_2 = "abcde".split("");
var VAR_3 = 0,
  VAR_4 = VAR_2.length;
for (; VAR_3 < VAR_4; VAR_3++) {
  var VAR_5 = VAR_1[VAR_2[VAR_3]];
}