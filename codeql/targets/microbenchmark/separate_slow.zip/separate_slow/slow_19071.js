function FUNCTION_1(VAR_2) {
  VAR_1 += VAR_2;
}
for (var VAR_3 = 0; VAR_3 < 10; VAR_3++) {
  FUNCTION_1(VAR_3);
}