var VAR_3 = "";
for (var VAR_4 = 0; VAR_4 < VAR_2; ++VAR_4) {
  VAR_3 += VAR_1;
}