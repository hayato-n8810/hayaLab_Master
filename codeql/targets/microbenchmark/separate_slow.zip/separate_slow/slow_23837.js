function FUNCTION_1(VAR_1, VAR_2) {
  var VAR_3 = "" + Math.pow(10, VAR_2);
  return (VAR_3 + VAR_1).slice(-VAR_2);
}
FUNCTION_1(12, 2);