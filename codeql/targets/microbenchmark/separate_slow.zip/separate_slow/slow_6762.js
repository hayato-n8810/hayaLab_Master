VAR_1 = -1;
for (var VAR_3 = -2; VAR_3 != -1; VAR_1++, VAR_3 = VAR_2.indexOf("1", VAR_3 + 1));