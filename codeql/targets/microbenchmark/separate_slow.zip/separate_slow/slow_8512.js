for (var VAR_1 = 0; VAR_1 < 10000; VAR_1++) {
  var VAR_2 = 1 ^ 0;
}