function FUNCTION_3(VAR_4) {
  var VAR_5 = FUNCTION_1.toString().replace(/((\/\/.*$)|(\/\*[\s\S]*?\*\/))/gm, "");
  return VAR_5.slice(VAR_5.indexOf("(") + 1, VAR_5.indexOf(")")).match(/([^\s,]+)/g) || [];
}
FUNCTION_3(FUNCTION_2);