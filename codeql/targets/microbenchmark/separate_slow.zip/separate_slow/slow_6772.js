function FUNCTION_1(VAR_1, VAR_2) {
  return VAR_1.concat(VAR_2);
}
var VAR_3 = [],
  VAR_4 = [],
  VAR_5,
  VAR_6,
  VAR_7,
  VAR_8,
  VAR_9,
  VAR_10;
VAR_7 = [];
VAR_10 = 100;
VAR_9 = 0;
while (VAR_9 < VAR_10) {
  if (VAR_9 % 10 == 0) VAR_7.push(VAR_4 = []);
  VAR_4.push(Math.random());
  VAR_9++;
}
VAR_5 = VAR_7.length;
VAR_6 = VAR_7[0].length;
VAR_3 = VAR_7.reduce(FUNCTION_1);