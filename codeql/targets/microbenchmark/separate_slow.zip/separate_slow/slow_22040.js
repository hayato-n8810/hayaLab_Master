function FUNCTION_2(VAR_2) {
  if (VAR_2 <= 1) {
    return VAR_2;
  }
  var VAR_3, VAR_4, VAR_5, VAR_6;
  for (VAR_3 = 2, VAR_5 = 1, VAR_6 = 0; VAR_3 <= VAR_2; ++VAR_3) {
    VAR_4 = VAR_5 + VAR_6;
    VAR_6 = VAR_5;
    VAR_5 = VAR_4;
  }
  return VAR_4;
}
function FUNCTION_3(VAR_7) {
  VAR_7(10);
}
FUNCTION_3(FUNCTION_2);