(function getType(VAR_4, VAR_5, VAR_6) {
  for (var VAR_7 = 0, VAR_8 = VAR_1.VAR_8; VAR_7 < VAR_8; VAR_7++) {
    if (VAR_3 && VAR_3.indexOf(VAR_7) == -1) continue;
    if (VAR_1[VAR_7].KEY_1 !== VAR_2) continue;
    return VAR_1[VAR_7];
  }
})(VAR_1, VAR_2, VAR_3);