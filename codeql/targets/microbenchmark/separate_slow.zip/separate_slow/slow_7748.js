function FUNCTION_1(VAR_1, VAR_2, VAR_3) {
  var VAR_4;
  for (var VAR_5 = 0; VAR_5 < 100; VAR_5++) {
    VAR_4 = VAR_1 + VAR_2 + VAR_3;
  }
  return VAR_4;
}
var VAR_6 = false,
  VAR_7 = true,
  VAR_8 = 1;
FUNCTION_1(VAR_6, VAR_7, VAR_8);