for (VAR_2 = 0; VAR_2 < 10; VAR_2++) {
  VAR_3.push(0);
}