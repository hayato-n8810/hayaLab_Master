var VAR_2 = new Array(VAR_1.KEY_1);
for (var VAR_3 = 0; VAR_3 < VAR_2.KEY_1; VAR_3++) {
  VAR_2[VAR_4] = new Array(VAR_1.KEY_1);
  for (var VAR_5 = 0; VAR_5 < VAR_2.KEY_1; VAR_5++) VAR_2[VAR_3][VAR_6] = 0;
}