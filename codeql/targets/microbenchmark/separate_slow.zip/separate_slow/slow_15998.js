var VAR_1;
function FUNCTION_1() {
  VAR_1 = 1234;
}
for (var VAR_2 = 0; VAR_2 <= 100; VAR_2++) {
  FUNCTION_1();
}