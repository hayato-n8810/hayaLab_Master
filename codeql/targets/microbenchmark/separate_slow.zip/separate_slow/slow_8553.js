var VAR_2 = 62648012;
function FUNCTION_1(VAR_3) {
  return 28 + (VAR_3 + Math.floor(VAR_3 / 8)) % 2 + 2 % VAR_3 + 2 * Math.floor(1 / VAR_3);
}
for (var VAR_4 = 1; VAR_4 < 12; VAR_4++) {
  VAR_1 = FUNCTION_1(VAR_4);
}