function FUNCTION_1() {
  eval(";");
  var VAR_1 = 0;
  for (var VAR_2 = 1; VAR_2 <= 1000; VAR_2++) {
    VAR_1 += VAR_2;
  }
}
function FUNCTION_2() {
  eval.call(null, ";");
  var VAR_3 = 0;
  for (var VAR_4 = 1; VAR_4 <= 1000; VAR_4++) {
    VAR_3 += VAR_4;
  }
}
FUNCTION_1();