function FUNCTION_1() {
  VAR_1 += 1;
}
l3: do {
  if (VAR_1 < VAR_2) FUNCTION_1();else break l3;
} while (true);