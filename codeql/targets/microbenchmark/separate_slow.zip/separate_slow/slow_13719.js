function FUNCTION_1(VAR_1) {
  return VAR_1 == VAR_1.split("").reverse().join("");
}
FUNCTION_1("madam");