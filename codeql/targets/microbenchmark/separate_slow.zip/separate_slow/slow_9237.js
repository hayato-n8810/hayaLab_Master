(function divideString(VAR_2, VAR_3) {
  var VAR_4 = [],
    VAR_5 = [],
    VAR_6 = 0;
  while (VAR_2[VAR_6]) {
    if (VAR_6 % VAR_3 == 0) {
      VAR_5 = [];
      VAR_4.push(VAR_5);
    }
    VAR_5.push(VAR_2[VAR_6]);
    VAR_6++;
  }
  return VAR_4;
})(VAR_1, 4);