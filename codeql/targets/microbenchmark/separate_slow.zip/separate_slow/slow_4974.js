for (; VAR_1--;) {
  if (!VAR_1) {
    break;
  }
}