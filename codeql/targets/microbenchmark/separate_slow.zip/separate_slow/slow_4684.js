for (var VAR_4 = 0; VAR_2 < 10000; VAR_2++) {
  VAR_3.push(VAR_1[VAR_2]);
}