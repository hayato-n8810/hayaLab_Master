while (VAR_2 < VAR_1.length) {
  (function () {
    VAR_1[VAR_2]++;
  })();
  VAR_2++;
}