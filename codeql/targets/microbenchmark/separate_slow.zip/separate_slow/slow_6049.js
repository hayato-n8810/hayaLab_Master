var FUNCTION_1 = function () {
  var VAR_1 = [1, 2, 3, 4, 5];
  this.FUNCTION_2 = function () {
    return VAR_1.length * 2;
  };
};
var VAR_2 = new FUNCTION_1();
for (var VAR_3 = 0, VAR_4 = VAR_2.FUNCTION_2(); VAR_3 < VAR_4; VAR_3++) {}