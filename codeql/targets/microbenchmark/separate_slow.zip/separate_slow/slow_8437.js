Array.prototype.FUNCTION_2 = function (VAR_3) {
  var VAR_4 = Object(this);
  var VAR_5 = VAR_4.length >>> 0;
  var VAR_6 = [];
  for (var VAR_7 = 0; VAR_7 < VAR_5; VAR_7++) {
    if (VAR_7 in VAR_4) {
      var VAR_8 = VAR_4[VAR_7];
      if (VAR_3(VAR_8)) VAR_6.push(VAR_8);
    }
  }
  return VAR_6;
};
VAR_1.FUNCTION_2(FUNCTION_1);