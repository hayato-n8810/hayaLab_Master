var VAR_2 = -1;
for (var VAR_3 = 0, VAR_4 = VAR_1.length; VAR_3 < VAR_4; VAR_3++) {
  if (VAR_1[VAR_3] === "o") {
    VAR_2 = VAR_3;
    break;
  }
}