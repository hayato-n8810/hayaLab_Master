for (var VAR_3 = 0; VAR_3 < 1000; VAR_3++) {
  if (VAR_2.charCodeAt(0) != "\\".charCodeAt(0)) {
    console.alert("fail");
  }
}