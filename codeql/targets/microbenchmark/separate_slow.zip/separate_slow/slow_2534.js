var VAR_5 = function (VAR_6) {
  return function () {
    VAR_6.apply(null, arguments);
  };
}(function (VAR_7, VAR_8, VAR_9) {
  VAR_4 += VAR_7 + VAR_8 + VAR_9;
});
for (var VAR_10 = 0; VAR_10 < VAR_1; VAR_10 += 1) {
  VAR_5(1, -1, 1);
}
FUNCTION_1(VAR_4, VAR_1);