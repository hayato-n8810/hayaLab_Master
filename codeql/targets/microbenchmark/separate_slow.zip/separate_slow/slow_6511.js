var VAR_1 = [];
var VAR_2 = 1000;
while (--VAR_2 > -1) {
  var VAR_3 = VAR_1[0] = 1;
}