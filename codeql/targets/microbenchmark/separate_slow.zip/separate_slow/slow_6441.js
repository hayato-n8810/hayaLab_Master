VAR_1.map(function (VAR_2) {
  console.log(VAR_2);
});