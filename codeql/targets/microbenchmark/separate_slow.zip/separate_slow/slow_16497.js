for (var VAR_4 = -1; Object.prototype.hasOwnProperty.call(VAR_1, VAR_4 += 1);) {
  VAR_3 = VAR_3 + VAR_4 + " = " + VAR_1[VAR_4] + " (" + FUNCTION_1(VAR_1[VAR_4]) + "), ";
}