function FUNCTION_1(VAR_5) {
  var VAR_6,
    VAR_7 = this.length;
  for (VAR_6 = 0; VAR_6 < VAR_7; VAR_6++) {
    if (this[VAR_6] === VAR_5) {
      return VAR_6;
    }
  }
  return -1;
}
var VAR_8 = FUNCTION_1.call(VAR_1, VAR_4) !== -1;