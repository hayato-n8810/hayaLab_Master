for (var VAR_2 = 0; VAR_2 < 10; VAR_2 += 1) {
  VAR_1.push(VAR_2);
}