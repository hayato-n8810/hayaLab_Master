let VAR_2 = new Set(Object.keys(VAR_1));
let VAR_3;
for (VAR_3 of VAR_2) {
  VAR_1[VAR_3] === 0;
}