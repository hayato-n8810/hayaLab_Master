for (var VAR_3 = 0;; VAR_3 += 1) {
  var VAR_4 = VAR_1[VAR_3];
  if (!VAR_4) {
    break;
  }
  VAR_4++;
}