function FUNCTION_1(VAR_1) {
  VAR_1.KEY_1(VAR_1.KEY_2() + 1);
}
var VAR_2 = 1;
var VAR_3 = {
  KEY_2: function () {
    return VAR_2;
  },
  KEY_1: function (VAR_4) {
    VAR_2 = VAR_4;
  }
};
var VAR_5 = 0;
for (var VAR_6 = 1000; VAR_6; VAR_6--) VAR_5 += FUNCTION_1(VAR_3);