for (var VAR_3 = 0; VAR_2 < 100; VAR_2++) {
  VAR_1.splice(0, 0, "This is a test" + VAR_2);
}