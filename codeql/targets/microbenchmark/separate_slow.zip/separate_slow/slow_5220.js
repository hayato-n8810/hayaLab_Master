for (var VAR_1 = 0; VAR_1 < 100; VAR_1++) {
  VAR_2 = new Array();
}