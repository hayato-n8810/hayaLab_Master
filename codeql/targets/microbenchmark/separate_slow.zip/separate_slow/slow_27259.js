for (var VAR_2 = 0; VAR_2 < 1000; ++VAR_2) {
  VAR_1 += VAR_2 % 2 === 0;
}