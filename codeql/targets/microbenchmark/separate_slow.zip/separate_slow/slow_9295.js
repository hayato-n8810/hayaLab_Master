while (VAR_1 !== VAR_1.replace(",", "|")) {
  VAR_1 = VAR_1.replace(",", "|");
}