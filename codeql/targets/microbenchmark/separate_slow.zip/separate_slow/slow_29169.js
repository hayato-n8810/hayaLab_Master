for (var VAR_6 = 0; VAR_4 < 1000; ++VAR_4) {
  var VAR_7 = VAR_2[VAR_4];
  VAR_3 = VAR_7 instanceof FUNCTION_1;
}