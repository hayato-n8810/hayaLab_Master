function FUNCTION_1(VAR_3) {
  for (let VAR_4 of VAR_1) {
    VAR_3(VAR_4);
  }
}
FUNCTION_1(VAR_5 => VAR_1.search(VAR_5) !== -1);