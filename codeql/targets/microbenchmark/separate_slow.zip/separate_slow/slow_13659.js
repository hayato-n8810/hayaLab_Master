var VAR_1, VAR_2, VAR_3, VAR_4;
VAR_4 = {
  KEY_1: "lk/dsljb/adsfads/adsfads/fdfgdfgas/asfasdf/fdf",
  KEY_2: "/w/a/xyz"
};
for (VAR_2 in VAR_4) {
  VAR_3 = VAR_4[VAR_2];
  VAR_1 = VAR_3.split("/");
  VAR_1.slice(0, VAR_1.lastIndexOf(VAR_2) + 1).join("/");
}