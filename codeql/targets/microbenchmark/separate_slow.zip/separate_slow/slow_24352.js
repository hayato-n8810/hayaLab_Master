try {
  while (VAR_1 < 10000) {
    VAR_1++;
  }
} catch (VAR_2) {
  VAR_3 = VAR_2;
}