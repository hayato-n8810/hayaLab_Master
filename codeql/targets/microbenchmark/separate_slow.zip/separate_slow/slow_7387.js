var VAR_3 = [];
for (var VAR_4 = 0; VAR_1.length > VAR_4; ++VAR_4) {
  VAR_3.push(FUNCTION_1(VAR_1[VAR_4]));
}