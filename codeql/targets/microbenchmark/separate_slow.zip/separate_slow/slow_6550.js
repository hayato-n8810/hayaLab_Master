var VAR_2 = [];
var VAR_3 = VAR_1.length;
for (var VAR_4 = 0; VAR_4 < VAR_3; ++VAR_4) {
  VAR_2.push(VAR_1[VAR_4]);
}