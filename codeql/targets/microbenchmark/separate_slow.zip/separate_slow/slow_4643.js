var VAR_4 = "",
  VAR_5 = VAR_1.length;
for (var VAR_6 = 0; VAR_6 != VAR_5; ++VAR_6) {
  VAR_4 += VAR_1[VAR_6].toString();
}