function FUNCTION_1(VAR_2) {
  var VAR_3;
  VAR_2 = VAR_2.split("|");
  for (var VAR_4 = 0, VAR_5 = VAR_2.length; VAR_4 < VAR_5; VAR_4 += 1) {
    VAR_1 = VAR_1.replace(new RegExp("\\{" + VAR_4 + "\\}"), VAR_2[VAR_4]);
  }
  return VAR_1;
}
FUNCTION_1("Joe|apple|green");