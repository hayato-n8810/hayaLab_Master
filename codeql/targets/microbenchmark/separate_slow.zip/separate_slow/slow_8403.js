(function () {
  var VAR_2 = 0;
  (function () {
    var VAR_3 = 0;
    for (VAR_4 = 0; VAR_4 < 10000; VAR_4++) {
      VAR_2 += VAR_4;
    }
  })();
})();