for (var VAR_2 = VAR_1.length; VAR_2--;) {
  VAR_1[VAR_2].KEY_1();
}