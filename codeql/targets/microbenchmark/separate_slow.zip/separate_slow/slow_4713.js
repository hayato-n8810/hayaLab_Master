var VAR_6 = VAR_1.slice(0),
  VAR_7;
while ((VAR_7 = VAR_6.shift()) !== undefined) {
  var VAR_8 = VAR_2.slice(0),
    VAR_9;
  FUNCTION_1(VAR_7);
}