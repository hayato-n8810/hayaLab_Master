for (var VAR_3 = 0; VAR_3 < 10; VAR_3++) {
  VAR_2.push(VAR_1[VAR_3]);
}