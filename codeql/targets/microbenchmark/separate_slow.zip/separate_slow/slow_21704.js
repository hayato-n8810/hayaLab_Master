for (var VAR_2 = 0; VAR_2 < VAR_1.length; VAR_2++) {
  var VAR_3 = parseInt(VAR_1[VAR_2], 10);
  isNaN(VAR_3) ? VAR_1[VAR_2] : VAR_3;
}