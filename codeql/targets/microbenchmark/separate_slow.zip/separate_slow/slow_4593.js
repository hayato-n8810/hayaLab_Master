for (var VAR_2 = 0; VAR_2 < 1000; VAR_2++) {
  parseInt(VAR_2 / VAR_1);
}