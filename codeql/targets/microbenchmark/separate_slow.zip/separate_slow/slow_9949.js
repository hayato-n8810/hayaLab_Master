function FUNCTION_1(VAR_2) {
  for (var VAR_3 in VAR_1) {
    if (VAR_3 == VAR_2) return VAR_3;
  }
}
FUNCTION_1();