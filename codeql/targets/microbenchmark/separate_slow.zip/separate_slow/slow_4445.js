function FUNCTION_2(VAR_3, VAR_4) {
  var VAR_5 = VAR_1.VAR_5;
  for (var VAR_6 = 0; VAR_2 < VAR_5; VAR_2++) {
    VAR_4(VAR_1[VAR_2], VAR_2);
  }
}
var VAR_7 = 0;
FUNCTION_2(VAR_1, function (VAR_8) {
  VAR_7 += VAR_8;
});