while (VAR_2--) {
  var VAR_3 = VAR_1[VAR_2].split(",");
  var VAR_4 = VAR_3[0];
  var VAR_5 = VAR_3[1];
  if (typeof VAR_4 != "undefined" && typeof VAR_5[1] != "undefined") {}
}