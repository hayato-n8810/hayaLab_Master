var VAR_12 = [];
for (var VAR_13 = 0, VAR_14 = 9; VAR_13 < VAR_14; VAR_13++) VAR_12.push(0);