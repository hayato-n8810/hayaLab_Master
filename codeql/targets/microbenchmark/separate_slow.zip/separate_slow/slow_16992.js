var VAR_4 = 0;
while (Object.prototype.hasOwnProperty.call(VAR_1, VAR_4)) {
  VAR_3 = VAR_3 + VAR_4 + " = " + VAR_1[VAR_4] + " (" + FUNCTION_1(VAR_1[VAR_4]) + "), ";
  VAR_4 = VAR_4 + 1;
}