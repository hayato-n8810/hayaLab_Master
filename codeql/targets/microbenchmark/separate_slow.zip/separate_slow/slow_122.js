for (var VAR_4 in VAR_1) {
  var VAR_5 = new RegExp(VAR_1[VAR_4]).test("343434fddfds");
}