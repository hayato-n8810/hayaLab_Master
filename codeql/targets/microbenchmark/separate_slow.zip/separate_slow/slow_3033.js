for (var VAR_2 = 1900; VAR_2 < 3000; VAR_2++) {
  VAR_1.splice(VAR_1.length, 0, VAR_2);
}