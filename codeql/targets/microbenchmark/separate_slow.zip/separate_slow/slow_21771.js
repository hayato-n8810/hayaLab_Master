var VAR_2 = [],
  VAR_3 = Object.prototype.hasOwnProperty;
for (var VAR_4 in VAR_1) {
  if (VAR_3.call(VAR_1, VAR_4)) VAR_2.push(VAR_1[VAR_4]);
}