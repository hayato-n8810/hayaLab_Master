var FUNCTION_1 = function (VAR_1) {
  var VAR_2, VAR_3, VAR_4;
  VAR_4 = "";
  for (VAR_2 = 0, VAR_3 = VAR_1.length; VAR_2 < VAR_3; VAR_2++) {
    VAR_4 += VAR_1[VAR_2] + " ";
  }
  return VAR_4.slice(0, -1);
};
var FUNCTION_2 = function (VAR_5) {
  var VAR_6, VAR_7, VAR_8;
  VAR_4 = VAR_1[0];
  for (VAR_2 = 1, VAR_3 = VAR_1.length; VAR_2 < VAR_3; VAR_2++) {
    VAR_4 += " " + VAR_1[VAR_2];
  }
  return VAR_4;
};
FUNCTION_1("hello world");