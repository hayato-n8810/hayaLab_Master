var VAR_2 = 50;
for (var VAR_3 = 0; VAR_3 <= 500; VAR_3 += VAR_2) {
  VAR_1++;
}