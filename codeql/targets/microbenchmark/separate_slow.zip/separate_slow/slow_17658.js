function FUNCTION_1(VAR_1) {
  if (VAR_1 == 0) return 1;
  return FUNCTION_1(VAR_1 - 1) * VAR_1;
}
FUNCTION_1(7);