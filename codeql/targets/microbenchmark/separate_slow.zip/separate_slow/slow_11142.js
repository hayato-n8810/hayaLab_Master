VAR_1.forEach(function (VAR_2) {
  var VAR_3 = VAR_2.indexOf(".") + 1;
  while (!isNaN(VAR_2[VAR_3 + 1])) {
    VAR_3++;
  }
  return VAR_2[VAR_3] === "0";
});