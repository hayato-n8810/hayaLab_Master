for (; parseInt(VAR_1, 10); VAR_1--) {
  VAR_2 = 1;
}