var VAR_3 = [];
for (var VAR_4 = 0, VAR_5 = VAR_1.VAR_5; VAR_2 < VAR_5; VAR_2++) {
  VAR_3.push(VAR_1[VAR_2]);
}
var VAR_6 = Math.min.apply(null, VAR_3);