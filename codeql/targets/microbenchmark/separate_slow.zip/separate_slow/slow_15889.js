function FUNCTION_1(VAR_2) {
  var VAR_3 = Array.apply(null, arguments);
}
FUNCTION_1(VAR_1);