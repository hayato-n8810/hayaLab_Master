while ((VAR_3 = VAR_4.shift()) !== undefined) {
  FUNCTION_1(VAR_3);
}