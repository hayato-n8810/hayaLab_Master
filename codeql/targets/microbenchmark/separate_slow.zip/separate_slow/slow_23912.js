var VAR_3 = 0,
  VAR_4 = VAR_1.length;
while (true) {
  if (VAR_3 === VAR_4) break;
  VAR_2.push(VAR_1[VAR_3++]);
}