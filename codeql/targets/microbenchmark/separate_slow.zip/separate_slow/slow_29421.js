for (var VAR_7 = 0; VAR_4 < VAR_2.length; VAR_4++) {
  VAR_6.push(1 * VAR_2[VAR_4]);
}