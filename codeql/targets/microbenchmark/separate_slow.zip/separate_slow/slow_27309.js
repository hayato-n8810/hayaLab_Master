for (let VAR_3 of VAR_1) {
  VAR_3.KEY_1 *= 2;
}