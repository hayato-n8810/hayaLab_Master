for (var VAR_2 = 0; VAR_2 < 200000; VAR_2++) {
  VAR_1.split("_").join("");
}