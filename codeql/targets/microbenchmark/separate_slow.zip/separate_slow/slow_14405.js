function FUNCTION_2(VAR_6, VAR_7) {
  var VAR_8 = "";
  while (VAR_7-- > 0) VAR_8 += VAR_6;
  return VAR_8;
}
FUNCTION_2(VAR_1, VAR_3);