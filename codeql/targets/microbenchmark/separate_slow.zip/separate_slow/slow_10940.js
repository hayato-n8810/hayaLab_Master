for (var VAR_2 = 0; VAR_2 < 100; VAR_2++) {
  VAR_1 = VAR_1.concat("foo");
}