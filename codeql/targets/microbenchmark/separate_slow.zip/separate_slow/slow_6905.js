var VAR_1 = [];
"Mary had a little lamb".replace(/[A-Za-z]+(?=(\s[A-Za-z]+))/g, function (VAR_2, VAR_3) {
  VAR_1.push(VAR_2 + VAR_3);
  return VAR_2;
});