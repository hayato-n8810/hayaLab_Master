for (var VAR_10 = 0; VAR_10 < 100; VAR_10++) {
  VAR_11 = FUNCTION_2.call({}, 1, 2, 3, 4);
}