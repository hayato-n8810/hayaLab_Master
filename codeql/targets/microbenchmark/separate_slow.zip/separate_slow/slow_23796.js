var VAR_1 = [1, 2, 3, 4];
var VAR_2 = function () {
  var VAR_3 = [];
  for (var VAR_4 = VAR_1, VAR_5 = Array.isArray(VAR_4), VAR_6 = 0, VAR_7 = VAR_5 ? VAR_4 : VAR_4[Symbol.iterator]();;) {
    var VAR_8;
    if (VAR_5) {
      if (VAR_6 >= VAR_4.length) break;
      VAR_8 = VAR_4[VAR_6++];
    } else {
      VAR_6 = VAR_4.next();
      if (VAR_6.done) break;
      VAR_8 = VAR_6.value;
    }
    var VAR_9 = VAR_8;
    VAR_3.push(VAR_9);
  }
  return VAR_3;
}();