for (var VAR_2 = 0; VAR_2 < 1000; VAR_2++) {
  FUNCTION_1.call(null, VAR_2);
}