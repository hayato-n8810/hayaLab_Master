var FUNCTION_1 = function (VAR_1, VAR_2) {
  var VAR_3 = VAR_1.VAR_3;
  if (VAR_3 === 0) return false;
  VAR_2 = VAR_2 || false;
  for (var VAR_4 = 0; VAR_4 < VAR_3; VAR_4++) {
    var VAR_5 = VAR_1.charCodeAt(VAR_4);
    if (VAR_2) {
      if (VAR_5 === 44 || VAR_5 === 46) {
        VAR_2 = false;
        continue;
      }
    }
    if (VAR_5 < 48 || VAR_5 > 57) return false;
  }
  return true;
};
FUNCTION_1("1.1", true);