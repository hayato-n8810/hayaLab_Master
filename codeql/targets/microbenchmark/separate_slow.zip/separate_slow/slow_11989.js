var VAR_1 = [1, 2, 3, 4, 5],
  VAR_2;
for (VAR_2 in VAR_1) {
  VAR_1[VAR_2] * VAR_1[VAR_2];
}