var VAR_1 = [];
for (var VAR_2 = 20; VAR_2 < 1000; VAR_2++) {
  VAR_1[1000 - VAR_2] = String.fromCharCode(VAR_2);
}
function FUNCTION_1() {
  var VAR_3 = new Array(1000);
  for (var VAR_4 = 20; VAR_2 < 1000; VAR_2++) {
    VAR_3[VAR_5] = VAR_1[1000 - VAR_2];
  }
  return VAR_3.join("");
}
FUNCTION_1();