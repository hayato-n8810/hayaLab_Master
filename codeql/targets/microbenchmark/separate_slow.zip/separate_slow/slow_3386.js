for (var VAR_4 = 0; VAR_3 < 10100; VAR_3++) {
  VAR_2 = VAR_2.slice(1);
  VAR_2.push({
    KEY_3: Date.now(),
    KEY_4: 25
  });
}