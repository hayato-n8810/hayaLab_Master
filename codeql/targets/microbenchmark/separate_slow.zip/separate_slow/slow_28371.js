while ((VAR_2 = VAR_1.indexOf(" ")) >= 0) {
  VAR_1 = VAR_1.substring(0, VAR_2).concat(VAR_1.substring(VAR_2 + 1));
}