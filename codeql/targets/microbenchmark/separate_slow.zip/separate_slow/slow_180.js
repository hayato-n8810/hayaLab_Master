for (var VAR_4 = 0; VAR_4 < 1000000; VAR_4++) {
  var VAR_5 = Object.getOwnPropertyDescriptor(VAR_1, VAR_2);
}