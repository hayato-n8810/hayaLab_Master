for (var VAR_3 = 0; VAR_3 < 100; VAR_3++) {
  VAR_1 = VAR_1.concat(VAR_2);
}