function FUNCTION_1(VAR_1) {
  var VAR_2 = [],
    VAR_3 = VAR_1.toString();
  while (VAR_3.length > 3) {
    VAR_2.unshift(VAR_3.slice(-3));
    VAR_3 = VAR_3.slice(0, -3);
  }
  VAR_2.unshift(VAR_3);
  return VAR_2.join(".");
}
FUNCTION_1(10000);
FUNCTION_1(1053434000);
FUNCTION_1(105312341234123440000);
FUNCTION_1(100);