var FUNCTION_1 = function (VAR_2) {
  return Math.min(Math.max(VAR_2, 0), 1);
};
var FUNCTION_2 = function (VAR_3) {
  if (VAR_2 >= 0 && VAR_2 <= 1) {
    return VAR_2;
  } else if (VAR_2 < 0) {
    return 0;
  } else {
    return 1;
  }
};
for (VAR_2 in VAR_1) {
  FUNCTION_1(VAR_2);
}