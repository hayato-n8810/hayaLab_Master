function FUNCTION_1(VAR_1) {
  if (VAR_1 < 100) {
    FUNCTION_1(VAR_1 + 1);
  }
}
FUNCTION_1(0);