for (var VAR_4 of VAR_1) {
  VAR_3.push(VAR_4);
}