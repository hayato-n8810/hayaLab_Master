const VAR_1 = "lorem ipsum dolor sit amet";
let VAR_2 = [];
for (let VAR_3 = 0; VAR_3 < VAR_1.length; ++VAR_3) {
  const VAR_4 = VAR_1.charCodeAt(VAR_3);
  const VAR_5 = VAR_4 >> 8;
  if (VAR_5 > 0) VAR_2.push(VAR_5);
  const VAR_6 = VAR_4 & 255;
  VAR_2.push(VAR_6);
}
let VAR_7 = VAR_2;