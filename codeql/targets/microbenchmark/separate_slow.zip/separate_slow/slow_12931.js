function FUNCTION_1(VAR_1, VAR_2) {
  var VAR_3 = 0;
  for (var VAR_4 = 0; VAR_4 < VAR_1.length; VAR_4++) {
    if (VAR_1[VAR_4] === VAR_2) {
      VAR_3 += 1;
    }
  }
  return VAR_3;
}
FUNCTION_1("asdf", "a");
FUNCTION_1("asddsa", "d");