var VAR_6 = /^\d*\.?\d*$/;
var VAR_7 = /^\d+$/;
var VAR_8 = /\d*\.?\d*/i;
VAR_4 = false;
VAR_5 = "Underscore isNumber Negative";
for (var VAR_9 = 0; VAR_9 < VAR_1.length; VAR_9++) {
  VAR_6.test(VAR_1[VAR_9]) && VAR_1[VAR_9];
}