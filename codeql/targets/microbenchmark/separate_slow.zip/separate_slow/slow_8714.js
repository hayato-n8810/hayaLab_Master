const FUNCTION_1 = () => {
  const VAR_1 = new Date().getFullYear();
  return [...Array(20).keys()].map(VAR_2 => ({
    KEY_1: VAR_1 + VAR_2,
    KEY_2: VAR_1 + VAR_2
  }));
};
FUNCTION_1();