for (var VAR_2 = 1, VAR_3 = 1000; VAR_2 <= VAR_3; VAR_2++) {
  VAR_1 += Math.pow(VAR_2, 2);
}