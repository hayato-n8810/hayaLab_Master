var VAR_1 = {
  KEY_1: 10,
  KEY_2: 10
};
for (var VAR_2 = 0; VAR_2 < 100; VAR_2++) {
  VAR_1.KEY_1 += 1;
  VAR_1.KEY_2 += 1;
}