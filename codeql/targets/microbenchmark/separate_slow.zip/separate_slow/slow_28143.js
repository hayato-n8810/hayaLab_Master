(function () {
  var FUNCTION_1 = function () {
    return "string";
  };
  for (var VAR_1 = 0; VAR_1 < 10000; VAR_1++) {
    FUNCTION_1();
  }
})();