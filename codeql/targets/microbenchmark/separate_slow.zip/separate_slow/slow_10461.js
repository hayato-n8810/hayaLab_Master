for (var VAR_3 in VAR_1) {
  VAR_2 = VAR_2.concat(VAR_3);
  VAR_2 = VAR_2.concat(": ");
  VAR_2 = VAR_2.concat(VAR_1[VAR_3]);
  VAR_2 = VAR_2.concat("; ");
}