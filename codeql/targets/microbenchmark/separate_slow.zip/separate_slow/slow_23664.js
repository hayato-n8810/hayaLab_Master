while (VAR_2--) {
  VAR_1[VAR_2].match(/^string/i);
}