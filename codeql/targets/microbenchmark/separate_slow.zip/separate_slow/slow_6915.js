for (var VAR_5 = 0; VAR_5 < VAR_3; VAR_5++) {
  var VAR_6 = VAR_4[VAR_5];
}
VAR_4.VAR_7 = 0;
this.VAR_8 = 0;