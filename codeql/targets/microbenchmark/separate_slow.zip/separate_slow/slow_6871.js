function FUNCTION_1(VAR_2, VAR_3, VAR_4, VAR_5) {
  "use strict";

  return VAR_2 + VAR_3 + VAR_4 + VAR_5;
}
for (var VAR_6 = 0; VAR_6 < 100; VAR_6++) {
  VAR_7 = FUNCTION_1.call({}, 1, 2, 3, 4);
}