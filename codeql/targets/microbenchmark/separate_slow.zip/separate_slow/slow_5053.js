var VAR_2 = true;
for (var VAR_3 = 0; VAR_3 < 10000; ++VAR_3) {
  VAR_1 = VAR_2 ? "even" : "odd";
  VAR_2 = !VAR_2;
}