while (VAR_4--) {
  if (VAR_1[VAR_4] == 10) {
    VAR_3 = true;
  }
}