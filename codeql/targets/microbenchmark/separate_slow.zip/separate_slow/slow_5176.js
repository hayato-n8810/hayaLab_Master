for (VAR_2 = 0; VAR_2 < 100; VAR_2++) {
  VAR_1.unshift(Math.random());
}
for (VAR_2 = 0; VAR_2 < 100; VAR_2++) {
  VAR_1.shift();
}