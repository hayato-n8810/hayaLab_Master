var VAR_1 = [];
for (var VAR_2 = 0; VAR_2 < 100; VAR_2++) {
  VAR_1.push("cadena de prueba" + VAR_2);
}
var VAR_3 = VAR_1.join();