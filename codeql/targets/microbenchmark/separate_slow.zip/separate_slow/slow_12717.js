for (var VAR_1 = 0; VAR_1 < 10; VAR_1++) {
  (function () {
    var VAR_2 = VAR_1;
    FUNCTION_1 = function () {
      console.log(VAR_2);
    };
  })();
}