var VAR_2 = 0;
var VAR_3 = VAR_1.length;
for (var VAR_4 = 0; VAR_4 < VAR_1.length; VAR_4++) {
  VAR_2 += VAR_1[VAR_4];
}