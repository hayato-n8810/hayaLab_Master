for (var VAR_1 = 0; VAR_1 < 100000; VAR_1++) {
  VAR_1++;
}