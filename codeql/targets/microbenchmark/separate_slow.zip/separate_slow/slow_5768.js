function FUNCTION_1(VAR_2) {
  var VAR_3 = JSON.stringify(VAR_2);
  var VAR_4 = 0;
  VAR_3.replace(/(\[).*?(\[)/g, function () {
    VAR_4++;
  });
  return VAR_4;
}
FUNCTION_1(VAR_1);