var VAR_2 = Array.prototype.shift;
var VAR_3 = Array.prototype.slice;
(function () {
  var VAR_4 = VAR_2.call(arguments);
  FUNCTION_1.apply(this, arguments);
})("name", 1, 2, 3, 4, 5);