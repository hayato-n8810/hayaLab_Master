function FUNCTION_1(VAR_1) {
  var VAR_2 = "sorry";
  var VAR_3 = "";
  for (var VAR_4 = 0; VAR_4 < VAR_1.length; VAR_4++) {
    var VAR_5 = 0;
    for (var VAR_6 = 0; VAR_6 < VAR_1.length; VAR_6++) {
      if (VAR_1[VAR_4] === VAR_1[VAR_6]) {
        VAR_5++;
      }
    }
    if (VAR_5 === 1) {
      return VAR_1[VAR_4];
    }
  }
  return VAR_2;
}
FUNCTION_1("ABCDBIRDUP");
FUNCTION_1("XXXXXXX");