for (var VAR_3 in VAR_2) {
  if (VAR_2.hasOwnProperty(VAR_3)) {
    VAR_1.push(VAR_3);
  }
}