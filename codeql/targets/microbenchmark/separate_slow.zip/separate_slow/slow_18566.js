function FUNCTION_1(VAR_1) {
  if (VAR_1 == null || typeof VAR_1.sort != "function") {
    return 0;
  }
  var VAR_2 = 1,
    VAR_3 = 1;
  for (var VAR_4 = 0; VAR_4 < VAR_1.length; ++VAR_4) {
    if (VAR_3 < VAR_2 + FUNCTION_1(VAR_1[VAR_4])) {
      VAR_3 = VAR_2 + FUNCTION_1(VAR_1[VAR_4]);
    }
  }
  return VAR_3;
}
var VAR_5 = [[1, 2, [3, 4]], [1, [2, 3], [4, 3, 5, [5, 6, [7, 8]]]], [2, 3, 4, 5], [1, 3, 5, 7, 9]];
FUNCTION_1(VAR_5);