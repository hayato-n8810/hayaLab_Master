var FUNCTION_1 = function () {
  var VAR_1 = 0;
  var VAR_2 = arguments.length;
  while (VAR_2--) {
    VAR_1 += arguments[VAR_2];
  }
  return VAR_1 & 4294967295;
};
var FUNCTION_2 = function (VAR_3, VAR_4) {
  return VAR_3 + VAR_4;
};
var FUNCTION_3 = function () {
  var VAR_5 = 0;
  var VAR_6 = arguments.length;
  while (VAR_2--) {
    VAR_1 += arguments[VAR_2];
  }
  return VAR_1;
};
var VAR_7 = FUNCTION_1(9876543210, 9876543210, 9876543210, 9876543210);