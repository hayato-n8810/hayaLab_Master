for (var VAR_4 = 0, VAR_5 = VAR_1.length; VAR_2 < VAR_5; VAR_2++) {
  VAR_6 += Math.ceil(VAR_1[VAR_2]);
}