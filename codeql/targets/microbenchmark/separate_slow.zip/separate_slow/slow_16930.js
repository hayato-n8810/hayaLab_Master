function FUNCTION_1(VAR_1, VAR_2) {
  var VAR_3 = 0;
  for (var VAR_4 = 0; VAR_4 < VAR_1.length; VAR_4++) {
    if (VAR_2(VAR_1[VAR_4])) {
      VAR_3++;
    }
  }
  return VAR_3;
}
FUNCTION_1([1, 3, 3, 4, 5], function (VAR_5) {
  return VAR_5 == 3;
});