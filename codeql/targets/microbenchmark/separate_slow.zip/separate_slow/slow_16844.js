for (var VAR_4 = 0; VAR_4 < VAR_3.length; VAR_4++) {
  VAR_1.KEY_1(VAR_3[VAR_4]);
}