for (var VAR_3 = 0; VAR_3 < VAR_1.length; VAR_3++) {
  if (VAR_1[VAR_3].KEY_1 != "test2") {
    VAR_2 = VAR_2.concat(VAR_1[VAR_3]);
  }
}