var VAR_1 = 0;
var FUNCTION_1 = function () {
  VAR_1++;
};
while (VAR_1 < 100) FUNCTION_1();