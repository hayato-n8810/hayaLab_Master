VAR_3 = -1;
while (++VAR_3 < VAR_2) {
  VAR_4 = VAR_3 + 1;
}