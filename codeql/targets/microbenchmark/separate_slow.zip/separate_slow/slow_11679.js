var VAR_1 = {
  0: "a",
  1: "b",
  2: "c",
  3: "d",
  4: "e",
  5: "f",
  6: "g"
};
var VAR_2 = Object.keys(VAR_1).length;
for (var VAR_3 in VAR_1) {
  var VAR_4 = VAR_1[VAR_3];
}