function FUNCTION_1(VAR_1) {
  var VAR_2 = [];
  for (var VAR_3 = 0, VAR_4 = 0; VAR_3 < VAR_1.length; VAR_3++) {
    VAR_2[VAR_4++] = VAR_1[VAR_1.length - 1 - VAR_3];
  }
  return VAR_2;
}
FUNCTION_1("Abhisek");