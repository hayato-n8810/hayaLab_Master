for (var VAR_1 = 0; VAR_1 < 20; ++VAR_1) {
  var VAR_2 = !!1;
  var VAR_3 = !!"string";
}