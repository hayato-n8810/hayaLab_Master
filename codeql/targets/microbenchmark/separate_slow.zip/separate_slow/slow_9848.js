VAR_2 = Array.prototype.map.call(VAR_1, function (VAR_3) {
  return VAR_3;
});