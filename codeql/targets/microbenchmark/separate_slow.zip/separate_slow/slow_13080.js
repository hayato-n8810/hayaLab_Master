var VAR_3 = VAR_1.length;
for (var VAR_4 = 0; VAR_4 < VAR_3; VAR_4++) {
  if (VAR_4 in VAR_1) {
    VAR_2 += VAR_1[VAR_4] || -100;
  }
}