Object.keys(VAR_1).forEach(function (VAR_2) {
  var VAR_3 = 0;
  for (var VAR_4 = 0, VAR_5 = VAR_1[VAR_2].length; VAR_4 < VAR_5; VAR_4++) VAR_3++;
});