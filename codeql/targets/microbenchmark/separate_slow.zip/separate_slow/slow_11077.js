function FUNCTION_1(VAR_1) {
  function FUNCTION_2(VAR_2, VAR_3, VAR_4) {
    if (VAR_4 === 1) return VAR_3;else return FUNCTION_2(VAR_3, VAR_2 + VAR_3, VAR_4 - 1);
  }
  if (VAR_1 === 0) return 0;else if (VAR_1 < 3) return 1;else return FUNCTION_2(0, 1, VAR_1);
}
FUNCTION_1(15);