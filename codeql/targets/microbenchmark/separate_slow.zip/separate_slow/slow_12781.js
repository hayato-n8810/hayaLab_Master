function FUNCTION_1(VAR_2, VAR_3) {
  var VAR_4 = VAR_3.split(".");
  for (index in VAR_4) {
    var VAR_5 = VAR_2[VAR_4[index]];
    switch (typeof VAR_5) {
      case "object":
        VAR_2 = VAR_5;
        break;
      case "undefined":
        return false;
      default:
        return VAR_5;
        break;
    }
  }
}
FUNCTION_1(VAR_1, "info.personal.firstName");