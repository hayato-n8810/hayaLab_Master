var VAR_1 = "1e20";
for (var VAR_2 = 0; VAR_2 < 300; VAR_2++) {
  +VAR_1;
}