var VAR_3 = [],
  VAR_4 = VAR_1;
for (; VAR_4;) VAR_3[--VAR_4] = VAR_2;