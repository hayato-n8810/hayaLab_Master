function FUNCTION_1(VAR_1) {
  var VAR_2 = 0,
    VAR_3 = 0,
    VAR_4 = arguments,
    VAR_5 = VAR_4.length,
    VAR_6,
    VAR_7 = [];
  for (; VAR_2 < VAR_5; VAR_2++) {
    for (VAR_3 = 0, VAR_6 = VAR_4[VAR_2].length; VAR_3 < VAR_6; VAR_3++) {
      VAR_7.push(VAR_4[VAR_2][VAR_3]);
    }
  }
  return VAR_7;
}
var VAR_8 = [1, 2, 3, 4, 5, 6, 7, 8],
  VAR_9 = [5, 7, 8, 9, 10];
FUNCTION_1(VAR_8, VAR_9);