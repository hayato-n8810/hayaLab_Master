var VAR_3 = [];
for (var VAR_4 = 0; VAR_4 < 300000; ++VAR_4) {
  VAR_3.push(VAR_1[50]);
}