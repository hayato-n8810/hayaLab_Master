var VAR_4 = [{
    KEY_1: "a",
    KEY_2: true
  }, {
    KEY_3: "b",
    KEY_4: false
  }, {
    KEY_5: "c",
    KEY_6: true
  }],
  VAR_5 = 0,
  VAR_6;
while (VAR_6 = VAR_4[VAR_3++]) {}