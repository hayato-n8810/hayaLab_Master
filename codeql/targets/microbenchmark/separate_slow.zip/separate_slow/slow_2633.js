VAR_1.forEach(function (VAR_5, VAR_6) {
  VAR_5.forEach(FUNCTION_1);
});