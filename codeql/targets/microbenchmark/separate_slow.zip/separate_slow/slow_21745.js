function FUNCTION_1(VAR_4, VAR_5) {
  var VAR_6;
  if (typeof VAR_5 !== "object" || VAR_5 === null) return VAR_4 === VAR_5;
  for (VAR_6 in VAR_5) if (!FUNCTION_1(VAR_4[VAR_6], VAR_5[VAR_6])) return false;
  return true;
}
FUNCTION_1(VAR_1, VAR_2);