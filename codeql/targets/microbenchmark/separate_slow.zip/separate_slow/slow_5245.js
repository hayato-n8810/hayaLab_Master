var VAR_3 = [],
  VAR_4 = 0;
for (; VAR_4 < VAR_1;) VAR_3[VAR_4++] = VAR_2;