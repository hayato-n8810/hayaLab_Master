var VAR_1 = 3,
  VAR_2 = Math.pow(10, VAR_1);
function FUNCTION_1(VAR_3) {
  return String((VAR_3 / VAR_2).toFixed(VAR_1)).slice(2, 2 + VAR_1);
}
FUNCTION_1(12);