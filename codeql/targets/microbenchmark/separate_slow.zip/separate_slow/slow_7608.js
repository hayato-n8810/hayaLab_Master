const FUNCTION_1 = (VAR_1, VAR_2) => {
  if (typeof VAR_1 !== "string" || typeof VAR_2 !== "string") {
    return false;
  }
  for (const VAR_3 of VAR_1) {
    if (!VAR_2.includes(VAR_3)) {
      return false;
    }
  }
  return true;
};
FUNCTION_1("cats", "dogs");
FUNCTION_1("satin", "stain");
FUNCTION_1("Dormitory", "Dirty room");