for (var VAR_4 = 0; VAR_4 < VAR_1.length; VAR_4++) {
  if (VAR_1[VAR_4] > VAR_2) VAR_5 = VAR_1[VAR_4];
  if (VAR_1[VAR_4] < VAR_3) VAR_6 = VAR_1[VAR_4];
}