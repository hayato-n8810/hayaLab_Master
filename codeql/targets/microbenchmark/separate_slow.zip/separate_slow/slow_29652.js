function FUNCTION_2(VAR_4, VAR_5, VAR_6) {
  if (VAR_6 % 100 == 0) {
    return new FUNCTION_1({
      KEY_1: VAR_5,
      KEY_2: VAR_4
    });
  }
  return new FUNCTION_1({
    KEY_3: VAR_4,
    KEY_4: VAR_5
  });
}
for (var VAR_7 = 0; VAR_7 < 1000000; VAR_7++) {
  var VAR_8 = FUNCTION_2(1, 2, VAR_7);
}