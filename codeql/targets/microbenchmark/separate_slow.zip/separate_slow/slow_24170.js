function FUNCTION_1(VAR_5) {
  for (var VAR_6 = 0, VAR_7 = []; VAR_5.length != 0;) {
    VAR_7[VAR_1++] = VAR_5[VAR_8 = Math.VAR_8() * VAR_5.length >> 0];
    VAR_5.splice(VAR_8, 1);
  }
  return VAR_7;
}
VAR_3 = FUNCTION_1(VAR_3);