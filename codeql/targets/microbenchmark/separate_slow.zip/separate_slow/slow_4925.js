for (VAR_1 = VAR_3; VAR_1 > 0; --VAR_1) {
  VAR_2 += 1;
}