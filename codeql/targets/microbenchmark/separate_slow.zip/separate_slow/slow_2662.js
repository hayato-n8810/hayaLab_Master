var VAR_1 = "";
for (var VAR_2 = 10000; VAR_2; VAR_2--) {
  VAR_1 += " ";
}