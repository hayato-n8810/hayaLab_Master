VAR_1.forEach(function (VAR_5, VAR_6) {
  for (var VAR_7 = 0, VAR_8 = VAR_2.length; VAR_7 < VAR_8; ++VAR_7) {
    VAR_2[VAR_7] - VAR_5;
  }
});