for (var VAR_3 = 0, VAR_4; VAR_3 <= VAR_1.length; VAR_4 = VAR_1[VAR_3++]) {
  VAR_4 * VAR_4;
}