function FUNCTION_1(VAR_2) {
  var VAR_3 = 0;
  var VAR_4 = 0;
  for (var VAR_5 = 0; VAR_5 < VAR_1.length; VAR_5 += 1) {
    VAR_6 = VAR_1.charCodeAt(VAR_5);
    if (VAR_6 > 48 && VAR_6 < 58) VAR_3 += parseInt(VAR_1[VAR_5]);else if (VAR_6 > 64 && VAR_6 < 91 || VAR_6 > 96 && VAR_6 < 123) VAR_4 += 1;
  }
  return Math.round(VAR_3 / VAR_4);
}
VAR_7 = FUNCTION_1(VAR_1);