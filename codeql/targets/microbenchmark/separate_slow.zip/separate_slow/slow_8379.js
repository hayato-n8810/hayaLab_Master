var VAR_2 = null;
for (var VAR_3 = 1; VAR_3 <= 100; VAR_3++) {
  VAR_1.set(VAR_3, "value " + VAR_3);
}
for (var [VAR_4, VAR_5] of VAR_1) {
  VAR_2 = VAR_5;
}