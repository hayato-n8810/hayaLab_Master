for (var VAR_3 = 0; VAR_2 < 10000; VAR_2++) {}
for (var VAR_4 = 0; VAR_2 < 10000; VAR_2++) {}