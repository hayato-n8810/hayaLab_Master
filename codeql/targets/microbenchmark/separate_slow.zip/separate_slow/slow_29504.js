for (var VAR_3 = 0; VAR_2 < 100; VAR_2++) {
  VAR_1.unshift("This is a test" + VAR_2);
}