var VAR_3 = [];
for (var VAR_4 = 0, VAR_5 = VAR_2.length; VAR_4 < VAR_5; VAR_4++) {
  VAR_3.push(VAR_2[VAR_4]);
}
VAR_3 = VAR_3.join("");