var VAR_3, VAR_4, VAR_5, VAR_6;
VAR_6 = [];
for (VAR_2 = 0, VAR_4 = VAR_1.length; VAR_2 < VAR_4; VAR_2++) {
  VAR_5 = VAR_1[VAR_2];
  VAR_6.push(VAR_5.KEY_1);
}