function FUNCTION_1(VAR_1) {
  for (var VAR_2 in VAR_3 = [-1, 0.25, 0.5, 0.75, 1]) if (VAR_1 <= VAR_3[VAR_2]) return "tag" + VAR_2;
}
for (var VAR_4 = 1; VAR_4 < 10; VAR_4++) FUNCTION_1(VAR_4 / 10);