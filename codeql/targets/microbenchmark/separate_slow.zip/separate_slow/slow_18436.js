var VAR_2 = VAR_1 && VAR_1[0];
for (var VAR_3 = 1, VAR_4 = VAR_1.length; VAR_3 < VAR_4; VAR_3++) {
  VAR_2 += " " + VAR_1[VAR_3];
}