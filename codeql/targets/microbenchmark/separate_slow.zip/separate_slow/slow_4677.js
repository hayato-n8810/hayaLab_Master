function FUNCTION_1(VAR_5, VAR_6) {
  for (; VAR_1 < VAR_2.length; VAR_1++) {
    VAR_6.call(VAR_2[VAR_1], VAR_1);
  }
}
FUNCTION_1(VAR_2, function (VAR_7) {
  VAR_3 += VAR_2[VAR_1];
});