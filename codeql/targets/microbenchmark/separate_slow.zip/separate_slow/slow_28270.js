var VAR_1 = ["123456", "234567", "345678", "456789", "012345"];
var VAR_2 = VAR_1.length;
while (VAR_2--) {
  if (VAR_1[VAR_2] === "234567") {
    break;
  }
}