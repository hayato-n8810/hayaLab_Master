while (VAR_1 < VAR_2) {
  function FUNCTION_1() {
    VAR_1++;
  }
  FUNCTION_1();
}