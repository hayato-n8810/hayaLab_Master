for (var VAR_4 = 0; VAR_2 < 100; ++VAR_2) {
  VAR_1.push(VAR_2 + 100);
}