for (let VAR_6 = 0; VAR_6 < VAR_1; ++VAR_6) {
  switch (VAR_2[2]) {
    case "t":
      ++VAR_3;
      break;
    case "i":
    case "n":
    case "m":
      ++VAR_4;
      break;
    default:
      {
        ++VAR_5;
        break;
      }
  }
}