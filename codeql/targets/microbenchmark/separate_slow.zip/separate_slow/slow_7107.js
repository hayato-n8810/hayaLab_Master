function FUNCTION_1(VAR_1) {
  let VAR_2 = "";
  for (let VAR_3 = 0; VAR_3 < VAR_1.length; VAR_3++) {
    for (let VAR_4 = 0; VAR_4 <= VAR_3; VAR_4++) {
      VAR_2 += VAR_4 === 0 ? VAR_1.charAt(VAR_3).toUpperCase() : VAR_1.charAt(VAR_3).toLowerCase();
    }
    if (VAR_3 !== VAR_1.length - 1) {
      VAR_2 += "-";
    }
  }
  return VAR_2;
}
FUNCTION_1("HbideVbxncC");