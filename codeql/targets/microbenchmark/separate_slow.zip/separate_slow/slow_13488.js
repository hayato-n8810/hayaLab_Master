var VAR_4 = 1;
for (VAR_3 = 0; VAR_3 < VAR_1.length; VAR_3++) {
  var VAR_5 = VAR_4 + VAR_1[VAR_3].foo;
  if (VAR_5 < 7) continue;
}