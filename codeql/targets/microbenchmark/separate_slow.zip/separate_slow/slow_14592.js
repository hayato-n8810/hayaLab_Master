function FUNCTION_1(VAR_4) {
  return 28 | 62648012 >> VAR_4 >> VAR_4 & 3;
}
for (var VAR_5 = 1; VAR_5 < 12; VAR_5++) {
  VAR_1 = FUNCTION_1(VAR_5);
}