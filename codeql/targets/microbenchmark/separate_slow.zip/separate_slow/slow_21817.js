var VAR_2;
for (VAR_2 in VAR_1) {}