while (VAR_3.length > 0) {
  VAR_3.shift();
}