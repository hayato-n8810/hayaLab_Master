var VAR_2 = 0;
while (VAR_1[VAR_2]) {
  if (VAR_1[VAR_2] === "Plum") {
    break;
  }
  VAR_2++;
}