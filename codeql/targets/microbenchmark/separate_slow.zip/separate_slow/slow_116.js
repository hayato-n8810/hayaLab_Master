VAR_1.map(function (VAR_3) {
  VAR_3.VAR_4 = VAR_3.KEY_1 + VAR_3.KEY_1;
});