while (VAR_1.length > 0) {
  VAR_1.shift();
}