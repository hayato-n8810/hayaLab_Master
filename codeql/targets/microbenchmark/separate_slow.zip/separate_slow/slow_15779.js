var VAR_3 = VAR_1.filter(function (VAR_4, VAR_5) {
  return VAR_4 == VAR_2[VAR_5];
}).length;