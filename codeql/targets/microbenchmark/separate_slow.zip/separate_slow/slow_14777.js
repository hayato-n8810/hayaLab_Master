function FUNCTION_1(VAR_1) {
  return Math.abs(VAR_1);
}
function FUNCTION_2(VAR_2) {
  return VAR_2 > 0 ? VAR_2 : -VAR_2;
}
for (var VAR_3 = -5; VAR_3 <= 5; VAR_3++) var VAR_4 = FUNCTION_1(VAR_4);