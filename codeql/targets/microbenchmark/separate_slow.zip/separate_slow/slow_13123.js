for (var VAR_2 = 0, VAR_3 = VAR_1.length; VAR_2 < VAR_3; VAR_2++) {
  var VAR_4 = Math.ceil(VAR_1[VAR_2]);
  VAR_4 > VAR_1[VAR_2] ? --VAR_4 : VAR_4;
}