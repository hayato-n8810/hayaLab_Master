var VAR_1 = "Dr Nicholas Mordecai";
var VAR_2 = "";
var VAR_3 = 0;
for (var VAR_4 = 0; VAR_4 < VAR_1.length; VAR_4++) {
  if (VAR_1[VAR_4] === " ") {
    VAR_3++;
  }
  if (VAR_3 === 1) {
    VAR_2 += VAR_1[VAR_4];
  }
}