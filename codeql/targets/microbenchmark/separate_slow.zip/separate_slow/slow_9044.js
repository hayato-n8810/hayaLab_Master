for (var VAR_3 of VAR_1) {
  void VAR_3;
}