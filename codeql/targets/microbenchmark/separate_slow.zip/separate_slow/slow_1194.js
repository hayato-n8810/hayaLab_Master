function FUNCTION_3() {
  var VAR_5 = [],
    VAR_6 = new Array(50000);
  VAR_5.concat.apply(VAR_5, VAR_6);
}
FUNCTION_3();