for (var VAR_6 = 0; VAR_6 < 2000; VAR_6++) {
  VAR_5 = VAR_3.indexOf("v" + VAR_6) > -1;
}