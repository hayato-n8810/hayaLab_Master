VAR_4 = VAR_2.map(function (VAR_7) {
  return VAR_7.KEY_1;
});