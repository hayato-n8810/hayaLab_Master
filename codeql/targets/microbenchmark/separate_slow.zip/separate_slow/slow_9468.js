for (VAR_3 = 1; VAR_3 <= 10; VAR_3++) {
  for (VAR_2 = -10; VAR_2 < 10; VAR_2++) {
    VAR_1 = VAR_2 - Math.floor(VAR_2 / VAR_3) * VAR_3;
  }
}