const VAR_2 = {
  KEY_5: /"|{|:|,|}/g,
  KEY_6: {
    '"': "",
    "{": "",
    ":": "(",
    ",": ") ",
    "}": ")"
  },
  '"': /"/g,
  "{": /{/g,
  ":": /:/g,
  ",": /,/g,
  "}": /}/g
};
const VAR_3 = JSON.stringify(VAR_1).replace(VAR_2['"'], "").replace(VAR_2["{"], "").replace(VAR_2[":"], "(").replace(VAR_2[","], ") ").replace(VAR_2["}"], ")");