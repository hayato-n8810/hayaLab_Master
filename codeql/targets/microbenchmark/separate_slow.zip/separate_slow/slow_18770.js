var VAR_1 = ["Rule1", "Rule2", "Rule3"];
var VAR_2 = {
  KEY_1: true,
  KEY_2: true,
  KEY_3: true
};
for (var VAR_3 in VAR_2) {
  VAR_1.indexOf(VAR_3) !== -1;
}