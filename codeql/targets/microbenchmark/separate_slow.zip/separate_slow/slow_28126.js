VAR_2 = VAR_1.reduceRight(function (VAR_3, VAR_4) {
  VAR_3.unshift(VAR_4);
  return VAR_3;
}, VAR_2);