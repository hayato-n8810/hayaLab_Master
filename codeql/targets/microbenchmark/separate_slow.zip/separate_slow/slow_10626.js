for (VAR_2 = 0; VAR_2 < 100000; VAR_2++) {
  if (VAR_1 instanceof String && VAR_1 == "verde") true;
}