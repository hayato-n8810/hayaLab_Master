var VAR_4 = VAR_1.length,
  VAR_5 = [],
  VAR_6;
for (VAR_6 = 0; VAR_6 < VAR_4; VAR_6++) {
  VAR_5.push(new FUNCTION_1(VAR_1[VAR_6]));
}