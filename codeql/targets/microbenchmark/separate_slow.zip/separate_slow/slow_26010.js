for (var VAR_3 = 0, VAR_4 = VAR_1.length; VAR_3 < VAR_4; VAR_3++) {
  if (VAR_1.charAt(VAR_3) == "Y" && VAR_1.charAt(VAR_3 + 1) == "Y" && VAR_1.charAt(VAR_3 + 2) == "Y" && VAR_1.charAt(VAR_3 + 3) == "Y") {
    VAR_2 = true;
  }
}