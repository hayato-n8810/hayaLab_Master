for (var VAR_3 = 0; VAR_3 < VAR_1; VAR_3++) {
  for (var VAR_4 = 0; VAR_4 < VAR_1; VAR_4++) {
    VAR_2[VAR_1 - VAR_4 - 1 + VAR_3 * VAR_1] = 10;
  }
}