var VAR_1;
VAR_1 = 1000;
while (VAR_1) {
  VAR_1--;
}