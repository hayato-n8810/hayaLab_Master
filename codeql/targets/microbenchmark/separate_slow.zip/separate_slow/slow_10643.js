function FUNCTION_1(VAR_4) {
  return new RegExp(VAR_1.join("|")).test(VAR_4);
}
function FUNCTION_2(VAR_5) {
  return VAR_3.test(VAR_5);
}
VAR_2 = "http://www.google.com";
FUNCTION_1(VAR_2);