var VAR_1 = 0;
var VAR_2 = [1, 1, 1, 1, 1];
var VAR_3 = VAR_2.length;
while (--VAR_3 >= 0) {
  VAR_1 += VAR_2[VAR_3];
}