(function () {
  for (var VAR_9 in VAR_1) if (VAR_1.hasOwnProperty(VAR_9)) {
    VAR_2++;
  }
})();