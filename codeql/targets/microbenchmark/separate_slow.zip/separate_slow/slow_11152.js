var VAR_2 = {
  1: {
    KEY_1: 1,
    KEY_2: "data1"
  },
  2: {
    KEY_3: 2,
    KEY_4: "data2"
  },
  3: {
    KEY_5: 3,
    KEY_6: "data3"
  }
};
for (var VAR_3 in VAR_2) {
  VAR_1 = VAR_3.KEY_2;
}