for (var VAR_4 = 0, VAR_5 = VAR_1.VAR_6; VAR_4 < VAR_5; VAR_4++) {
  var VAR_6 = VAR_2.VAR_6;
  while (VAR_6-- && VAR_2[VAR_6] !== VAR_1[VAR_4]) {}
  if (VAR_6 >= 0) {
    VAR_3 = false;
    break;
  }
}