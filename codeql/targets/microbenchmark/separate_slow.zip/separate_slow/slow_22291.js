var VAR_2 = 0;
for (var VAR_3 = 0; VAR_3 < VAR_1.length; VAR_3++) {
  var VAR_4 = VAR_1.charCodeAt(VAR_3);
  VAR_2 <<= 4;
  if (VAR_4 >= 48 && VAR_4 < 58) {
    VAR_2 += VAR_4 - 48;
  } else if (VAR_4 >= 97 && VAR_4 <= 122) {
    VAR_2 += VAR_4 - 97 + 10;
  } else if (VAR_4 >= 65 && VAR_4 <= 90) {
    VAR_2 += VAR_4 - 65 + 10;
  }
}