var VAR_3 = FUNCTION_1(100);
var VAR_4 = FUNCTION_1(1000);
var VAR_5 = FUNCTION_1(10000);
var VAR_6 = FUNCTION_1(100000);
while (VAR_5.length) {
  VAR_5.shift();
}