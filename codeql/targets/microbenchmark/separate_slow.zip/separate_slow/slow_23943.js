var VAR_1 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
var VAR_2 = 0;
var VAR_3 = VAR_1.VAR_3;
for (var VAR_4 = 0; VAR_4 < VAR_3; VAR_4++) {
  var VAR_5 = VAR_1[VAR_4];
}