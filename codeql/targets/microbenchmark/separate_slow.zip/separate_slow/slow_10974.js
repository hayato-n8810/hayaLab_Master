function FUNCTION_1(VAR_1, VAR_2, VAR_3) {
  if (!VAR_3 && VAR_3 !== 0) VAR_3 = " ";
  return (Array(VAR_2 + 1).join(VAR_3) + String(VAR_1)).slice(-1 * VAR_2);
}
FUNCTION_1("test", 5);