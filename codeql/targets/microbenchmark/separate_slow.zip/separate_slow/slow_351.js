var VAR_1 = ["Hello World"];
for (var VAR_2 = 0; VAR_2 < 100000; VAR_2++) {
  VAR_1.push("Hello World");
}
var VAR_3 = VAR_1.join("");