var VAR_4 = VAR_1.concat(VAR_2).sort();
for (var VAR_5 = 0; VAR_5 < VAR_4.length - 1; VAR_5++) VAR_4[VAR_5 + 1] === VAR_4[VAR_5] && VAR_3.push(VAR_4[VAR_5]);