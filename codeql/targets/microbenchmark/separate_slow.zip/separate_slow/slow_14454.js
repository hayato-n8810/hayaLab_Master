function FUNCTION_2() {
  eval.call(null, ";");
  var VAR_3 = 0;
  for (var VAR_4 = 1; VAR_4 <= 1000; VAR_4++) {
    VAR_3 += VAR_4;
  }
}
FUNCTION_2();